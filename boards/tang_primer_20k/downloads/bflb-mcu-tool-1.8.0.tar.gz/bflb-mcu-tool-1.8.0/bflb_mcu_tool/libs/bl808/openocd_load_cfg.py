# -*- coding:utf-8 -*-


openocd_shake_hand_addr = "2204BBE8"
openocd_data_addr = "2204CC88"
openocd_load_addr = "22010000"
openocd_core_type = "RISC-V"
openocd_set_tif = 0
openocd_run_addr = "22010000"
