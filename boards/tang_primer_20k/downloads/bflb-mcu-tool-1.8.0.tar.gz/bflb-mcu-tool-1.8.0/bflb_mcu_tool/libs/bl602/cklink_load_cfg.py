# -*- coding:utf-8 -*-


cklink_shake_hand_addr = "4201BFF0"
cklink_data_addr = "4201C000"
cklink_load_addr = "22010000"
cklink_core_type = "RISC-V"
cklink_set_tif = 0
cklink_run_addr = "22010000"
