# -*- coding:utf-8 -*-


from core import bflb_mcu_tool

def run_main():
    bflb_mcu_tool.run()

if __name__ == '__main__':
    run_main()